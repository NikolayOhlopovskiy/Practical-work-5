﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
       /// <summary>
       /// Вычисльть квадратные уравнения
       /// </summary>
       /// <param name="args"></param>
        static void Main(string[] args)
        {
            //Задание 1
            //1.
            //try
            //{
             
            //    Console.WriteLine("a=");
            //    int a = int.Parse(Console.ReadLine());
            //    Console.WriteLine("b=");
            //    int b = int.Parse(Console.ReadLine());
            //    Console.WriteLine("c=");
            //    int c = int.Parse(Console.ReadLine());
            //    double d = Math.Pow(b, 2) - 4 * a * c;
            //    if (d > 0)            //В скобках обозначают условие
            //    {
            //        Console.Write("2 корня");
            //        double x1 = (-b + Math.Sqrt(d)) / (2 * a);
            //        double x2 = (-b - Math.Sqrt(d)) / (2 * a);
            //        Console.WriteLine($"x1={x1:f2}/t x2={x2:f2}");
            //    }
            //    else if (d == 0)
            //    {
            //        Console.WriteLine("1 корень");
            //        double x = (-b + Math.Sqrt(d)) / 2 * a;
            //        Console.WriteLine($"x1={x}");
            //    }
            //    else
            //    {
            //        Console.WriteLine("Нет решений");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"Исключение: {ex.Message}");
            //    Console.WriteLine($"Метод: {ex.TargetSite}");
            //    Console.WriteLine($"Трассировка стека: {ex.StackTrace}");
            //}
            //2.
            //try
            //{
                // Ввод сторон треугольника
                //Console.Write("a=");
                //double a = Convert.ToDouble(Console.ReadLine());

                //Console.Write("b=");
                //double b = Convert.ToDouble(Console.ReadLine());

                //Console.Write("c=");
                //double c = Convert.ToDouble(Console.ReadLine());

                // Проверка существования треугольника
                //if (a + b > c && a + c > b && b + c > a)
                //{
                    // Полупериметр
                    //double p = (a + b + c) / 2;

                    // Площадь по формуле Герона
            //        double area= Math.Sqrt(p * (p - a) * (p - b) * (p - c));

            //        Console.WriteLine($"Площадь треугольника: {area}");
            //    }
            //    else
            //    {
            //        Console.WriteLine("Треугольник с такими сторонами не существует.");
            //    }
            //}
                   
                 Console.Read();



        }
    }
}
